Install the package
------------------- 
This package installs the following items:

/core/sitecore/system/Field types/Custom Types (folder)
/core/sitecore/system/Field types/Custom Types/Unbound Droplist (field)

Please reference the documentation to make sure appropriate config files and source code are added to your project as well.

